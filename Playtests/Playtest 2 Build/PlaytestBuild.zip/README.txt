HELLO!!

Form here: https://goo.gl/forms/xkZiLTRPwsnDObDN2


Thank you for playtesting the game!

This game requires 2 PLAYERS to be on the same keyboard.

Communication is important, so please make sure to talk out loud about everything in the game.


After playing the game until you think you are done (there is Pause menu for restart and returning to main menu btw), please fill out the form
while still on the recording and talk about your experience.



Thank you so much!